import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

/*
  Generated class for the UserServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/

const httpOptions = {
headers: new HttpHeaders({'Content-Type':'application/json'})
};

@Injectable()
export class UserServiceProvider {

  constructor(public http: HttpClient) {
    console.log('Hello UserServiceProvider Provider');
  }

getUsers() {
 return this.http.get('https://randomuser.me/api/?results=25');
}

getLibros() {
 return this.http.get('http://localhost:8080/PrestamoLibros/rs/libros/listalibros');
}

addLibro(data) {
  return new Promise((resolve, reject) => {
    this.http.post('http://localhost:8080/PrestamoLibros/rs/libros/nuevolibro', JSON.stringify(data), httpOptions)
      .subscribe(res => {
        resolve(res);
      }, (err) => {
        reject(err);
      });
  });
}

getDevo(codigo) {
  return this.http.get('http://localhost:8080/PrestamoLibros/rs/libros/devolu/' + codigo);
 }


}
