import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { UserServiceProvider } from '../../providers/user-service/user-service';
import { ReservavaServiceProvider } from '../../providers/reservava-service/reservava-service';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  users: any[] = [];
  libros: any[] = [];

  constructor(public navCtrl: NavController, public UserServiceProvider: UserServiceProvider, public resP: ReservavaServiceProvider) {
  }


  /*ionViewDidLoad(){
    this.UserServiceProvider.getUsers()
    .subscribe(
      (data) => { // Success
        this.users = data['results'];
      },
      (error) =>{
        console.error(error);
      }
    )
  }*/

  

  ionViewDidLoad(){
    this.UserServiceProvider.getLibros()
    .subscribe(
      (data) => { // Success
        this.libros = data['libro'];
      },
      (error) =>{
        console.error(error);
      }
    )
  }


}
