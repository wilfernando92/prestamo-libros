import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { UserServiceProvider } from '../../providers/user-service/user-service';
import { ReservavaServiceProvider } from '../../providers/reservava-service/reservava-service';

/**
 * Generated class for the PrestamosPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-prestamos',
  templateUrl: 'prestamos.html',
})
export class PrestamosPage {

  prestamos: any[] = [];

  constructor(public navCtrl: NavController, public navParams: NavParams, public UserServiceProvider2: UserServiceProvider, public resP2: ReservavaServiceProvider) {
  }

  

  ionViewDidLoad(){//this.devices.map(function(a) {return a["_id"];})
  console.log(this.resP2.GlobalVarS['sol_id']);
    this.resP2.getPrestamosUsuario(this.resP2.GlobalVarS['sol_id'])
    .subscribe(
      (data) => { // Success
        this.prestamos = data['pre'];
      },
      (error) =>{
        console.error(error);
      }
    )
  }

}
