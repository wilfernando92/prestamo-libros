import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DevolucionPage } from './devolucion';

@NgModule({
  declarations: [
    DevolucionPage,
  ],
  imports: [
    IonicPageModule.forChild(DevolucionPage),
  ],
})
export class DevolucionPageModule {}
