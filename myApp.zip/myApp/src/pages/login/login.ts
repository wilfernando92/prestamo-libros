import { Component } from '@angular/core';
import { IonicPage, NavController,LoadingController, Loading, AlertController} from 'ionic-angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { ReservavaServiceProvider } from '../../providers/reservava-service/reservava-service';
import { TabsPage } from '../../pages/tabs/tabs';

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

  myForm: FormGroup;
  usu: any[] = [];
  public loading:Loading;

  constructor(
    public navCtrl: NavController,
    public formBuilder: FormBuilder,
    public alertCtrl: AlertController,
    public loadingCtrl: LoadingController,
    public resProv: ReservavaServiceProvider
  ) {
    this.myForm = this.formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  loginUser(){

    console.log("Email:" + this.myForm.value.email);  
    console.log("Password:" + this.myForm.value.password);
   
    this.resProv.getUsu(this.myForm.value.email, this.myForm.value.password)
    .subscribe(
      (data) => { // Success
        this.usu = data['soli'];
        if(this.usu == null){
          let alert = this.alertCtrl.create({
            message: "Error al iniciar sesion, nombre de usuario o clave incorrectos.",
            buttons: [
              {
                text: "Ok",
                role: 'cancel'
              }
            ]
          });
          alert.present();
          this.navCtrl.setRoot(this.navCtrl.getActive().component);
        }else{
          this.resProv.GlobalVarS = data['soli'];
          this.resProv.ejem = "hola";
          this.navCtrl.setRoot(TabsPage); 
          
        }
    }, (err) => {
      this.loading.dismiss().then( () => {
        let alert = this.alertCtrl.create({
          message: err.message,
          buttons: [
            {
              text: "Ok",
              role: 'cancel'
            }
          ]
        });
        alert.present();
      });
    });

    //this.navCtrl.setRoot(this.navCtrl.getActive().component);

    

    

    /*this.afAuth.auth.signInWithEmailAndPassword(this.myForm.value.email, this.myForm.value.password).then(() => {
      console.log("User logging");
      this.navCtrl.setRoot('HomePage');
    }, (err) => {
      this.loading.dismiss().then( () => {
        let alert = this.alertCtrl.create({
          message: err.message,
          buttons: [
            {
              text: "Ok",
              role: 'cancel'
            }
          ]
        });
        alert.present();
      });
    });*/

    this.loading = this.loadingCtrl.create({
      dismissOnPageChange: true,
    });
    this.loading.present();
  }
  

  goToSignup(){
    this.navCtrl.push('SignupPage');
  }

  goToResetPassword(){
    this.navCtrl.push('ResetPasswordPage');
  }

}
