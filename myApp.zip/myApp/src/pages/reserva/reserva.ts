import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ReservavaServiceProvider } from '../../providers/reservava-service/reservava-service';

/**
 * Generated class for the ReservaPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-reserva',
  templateUrl: 'reserva.html',
})
export class ReservaPage {

myForm1: FormGroup;
myForm2: FormGroup;

soli: any[] = [];
lib: any[] = [];

    constructor(public navCtrl: NavController, public navParams: NavParams, public formBuilder: FormBuilder, public reseP: ReservavaServiceProvider, public toastCtrl: ToastController) {
  this.myForm1 = this.createMyForm();
  this.myForm2 = this.createMyForm2();
  }

sasa(){
console.log(this.myForm1.value.pre_sol_id);
    this.reseP.getSolicitante(this.myForm1.value.pre_sol_id)
    .subscribe(
      (data) => { // Success
        this.soli = data['soli'];
      },
      (error) =>{
        console.error(error);
      }
    );
}

newPrestamo = { pre_lib: '', pre_sol: '', pre_fecha_inicio: '', pre_fecha_fin: '', pre_estado: '', pre_cantidad: '' };
saveData2(){
console.log(this.reseP.GlobalVarS['sol_nombres']);

 /*'{pre_lib: '+ JSON.stringify(this.lib)+', pre_sol: '+ JSON.stringify(this.reseP.GlobalVarS)+
                   ', pre_fecha_inicio: "'+this.myForm1.value.pre_fecha_inicio+'", pre_fecha_fin: "'+this.myForm1.value.pre_fecha_fin+
                   '", pre_estado: "'+this.myForm1.value.pre_Estado+'", pre_cantidad: "'+this.myForm1.value.pre_cantidad+'"}';*/
this.newPrestamo = { pre_lib: this.lib+'', pre_sol: this.reseP.GlobalVarS+'', pre_fecha_inicio: this.myForm2.value.pre_fecha_inicio, pre_fecha_fin: this.myForm2.value.pre_fecha_fin, pre_estado: 'ACTIVO', pre_cantidad: this.myForm2.value.pre_cantidad };

//console.log('errr ' + this.myForm2.value.pre_fecha_inicio);
//console.log('lista - ' + JSON.stringify(this.newPrestamo));

//{lib_barras: "xyz", lib_nom: "Prueb", lib_editorial: "Pru", lib_autor: "Libro nuevo", lib_stk: "5"}


this.reseP.addPrestamo(this.newPrestamo).then((result) => {
  console.log(result);

let toast = this.toastCtrl.create({
message: 'Prestamo ingresado correctamente',
position: 'bottom',
duration: 3000
});
toast.present();

}, (err) => {

let toast = this.toastCtrl.create({
message: 'Error al ingresar el prestamo',
position: 'bottom',
duration: 3000
});
toast.present();

  console.log(err);
});
this.navCtrl.setRoot(this.navCtrl.getActive().component);








/*
  this.UserServiceProvider.addLibro(this.myForm.value).then((result) => {
 console.log(result);

let toast = this.toastCtrl.create({
message: 'Libro ingresado correctamente',
position: 'bottom',
duration: 3000
});
toast.present();

}, (err) => {

let toast = this.toastCtrl.create({
message: 'Error al ingresar el libro',
position: 'bottom',
duration: 3000
});
toast.present();

 console.log(err);
});
 console.log(this.myForm.value);
this.navCtrl.setRoot(this.navCtrl.getActive().component);*/
}


 private createMyForm(){
    return this.formBuilder.group({
      pre_lib_id: ['', Validators.required],
    });
  }

 private createMyForm2(){
    return this.formBuilder.group({
      pre_fecha_inicio: ['', Validators.required],
      pre_fecha_fin: ['', Validators.required],
      pre_cantidad: ['', Validators.required],
    });
  }

  ionViewDidLoad(){

console.log(' - LIBRO: ' + this.myForm1.value.pre_lib_id);
    /*this.reseP.getSolicitante(this.myForm1.value.pre_sol_id)
    .subscribe(
      (data) => { // Success
        this.soli = data['soli'];
      },
      (error) =>{
        console.error(error);
      }
    );*/

    this.reseP.getLib(this.myForm1.value.pre_lib_id)
    .subscribe(
      (data) => { // Success
        this.lib = data['libro'];
      },
      (error) =>{
        console.error(error);
      }
    );

  }



}
