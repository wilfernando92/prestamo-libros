import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ListaLibrosPage } from './lista-libros';

@NgModule({
  declarations: [
    ListaLibrosPage,
  ],
  imports: [
    IonicPageModule.forChild(ListaLibrosPage),
  ],
})
export class ListaLibrosPageModule {}
