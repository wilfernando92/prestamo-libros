package ups.edu.ec.controladores;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.enterprise.inject.Model;
import javax.enterprise.inject.Produces;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import ups.edu.ec.modelo.Libro;
import ups.edu.ec.modelo.PrestamoLibro;
import ups.edu.ec.modelo.Solicitante;
import ups.edu.ec.servicios.EnvioCorreo;
import ups.edu.ec.servicios.NegociosReserva;

@Model
public class ReporteController {

	@Inject
	private FacesContext facesContext;

	@Inject
	private NegociosReserva negociosP;

	@Inject
	private Logger log;

	@PostConstruct
	public void initNewPrestamo() {

	}

	/**
	 * Permite imprimir un reporte PDF del listado de prestamos en estado activo o inactivo
	 */
	public void imprimirReporte() {

		Document document = new Document(PageSize.LETTER);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try {
			PdfWriter.getInstance(document, baos);
			//Reporte de prestamos activos e inactivos
			List<PrestamoLibro> alList = negociosP.listadoPrestamoLibroAI();
			document.open();

			document.add(new Paragraph(" PRESTAMOS REGISTRADOS \n"));

			DateFormat formatter = new SimpleDateFormat("dd/MM/yy '-' hh:mm:ss");
			Date currentDate = new Date();
			String date = formatter.format(currentDate);
			document.add(new Paragraph(" Fecha Generacion: " + date));
			document.add(new Paragraph("\n"));

			PdfPTable table = new PdfPTable(6);

			table.setTotalWidth(new float[] { 35, 82, 110, 160, 72, 60 });
			table.setLockedWidth(true);

			PdfPCell cell = new PdfPCell(new Paragraph("Listado de Prestamos", FontFactory.getFont("arial", // fuente
					8, // tamaño
					Font.BOLD, // estilo
					BaseColor.WHITE)));
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setBackgroundColor(BaseColor.BLACK);
			cell.setColspan(6);
			table.addCell(cell);

			cell = new PdfPCell(new Paragraph("ID", FontFactory.getFont("arial", 8, Font.BOLD, BaseColor.GRAY)));

			table.addCell("Cod");
			
			table.addCell("Libro");

			table.addCell("Solicitante");

			table.addCell("Inicio / Fin Prestamo");

			table.addCell("Cantidad");

			table.addCell("Estado");

			for (int i = 0; i < alList.size(); i++) {
				PrestamoLibro id = alList.get(i);
				table.addCell(String.valueOf(id.getPre_id()));
				cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
				table.addCell(id.getPre_lib().getLib_nom());
				table.addCell(id.getPre_sol().getSol_nombres() + " " + id.getPre_sol().getSol_apellidos());
				table.addCell(id.getPre_fecha_inicio() + "/" + id.getPre_fecha_fin());
				table.addCell(id.getPre_cantidad());
				table.addCell(id.getPre_estado());
			}
			document.add(table);
		} catch (Exception ex) {
			System.out.println("Error " + ex.getMessage());
		}
		document.close();
		FacesContext context = FacesContext.getCurrentInstance();
		Object response = context.getExternalContext().getResponse();
		if (response instanceof HttpServletResponse) {
			HttpServletResponse hsr = (HttpServletResponse) response;
			hsr.setContentType("application/pdf");
			hsr.setHeader("Content-disposition", "attachment");
			hsr.setContentLength(baos.size());
			try {
				ServletOutputStream out = hsr.getOutputStream();
				baos.writeTo(out);
				out.flush();
			} catch (IOException ex) {
				System.out.println("Error:  " + ex.getMessage());
			}
			context.responseComplete();
		}
	}

	/*public void reset() {
		RequestContext.getCurrentInstance().reset("formEditar:panel");
	}*/

}
