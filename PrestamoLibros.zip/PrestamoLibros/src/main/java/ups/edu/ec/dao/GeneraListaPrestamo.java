package ups.edu.ec.dao;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.Observes;
import javax.enterprise.event.Reception;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;
import ups.edu.ec.modelo.PrestamoLibro;

import java.util.List;

@RequestScoped
public class GeneraListaPrestamo {

	@Inject
	private RepositorioReserva repositorioReserva;

	private List<PrestamoLibro> prestamos;

	@Produces
	@Named
	public List<PrestamoLibro> getPrestamos() {
		return prestamos;
	}

	public void listaPrestamosCambios(@Observes(notifyObserver = Reception.IF_EXISTS) final PrestamoLibro prestamo) {
		devuelveTodoOrden();
	}

	@PostConstruct
	public void devuelveTodoOrden() {
		prestamos = repositorioReserva.devuelveTodoOrdenandoFechaPrestamoLibro();
	}
}
