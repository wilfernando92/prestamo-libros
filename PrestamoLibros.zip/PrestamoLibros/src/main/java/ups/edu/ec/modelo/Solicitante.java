package ups.edu.ec.modelo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@SuppressWarnings("serial")
@Entity
@XmlRootElement
@Table(uniqueConstraints = @UniqueConstraint(columnNames = "sol_email"))
public class Solicitante implements Serializable {

	@Id
	@GeneratedValue
	@Column(name = "sol_id")
	private int sol_id;

	@NotNull
	@Size(min = 10, max = 10)
	@Digits(fraction = 0, integer = 10)
	@Column(name = "sol_cedula")
	private String sol_cedula;

	@NotNull
	@Size(min = 1, max = 70)
	@Pattern(regexp = "[^0-9]*", message = "Los nombres no pueden contener numeros")
	@Column(name = "sol_nombres")
	private String sol_nombres;

	@NotNull
	@Size(min = 1, max = 70)
	@Pattern(regexp = "[^0-9]*", message = "Los apellidos no pueden contener numeros")
	@Column(name = "sol_apellidos")
	private String sol_apellidos;

	@NotNull
	@NotEmpty
	@Column(name = "sol_direccion")
	private String sol_direccion;

	@NotNull
	@NotEmpty
	@Email
	@Column(name = "sol_email")
	private String sol_email;

	@NotNull
	@Size(min = 10, max = 10)
	@Digits(fraction = 0, integer = 10)
	@Column(name = "sol_celular")
	private String sol_celular;

	public int getSol_id() {
		return sol_id;
	}

	public void setSol_id(int sol_id) {
		this.sol_id = sol_id;
	}

	public String getSol_cedula() {
		return sol_cedula;
	}

	public void setSol_cedula(String sol_cedula) {
		this.sol_cedula = sol_cedula;
	}

	public String getSol_nombres() {
		return sol_nombres;
	}

	public void setSol_nombres(String sol_nombres) {
		this.sol_nombres = sol_nombres;
	}

	public String getSol_apellidos() {
		return sol_apellidos;
	}

	public void setSol_apellidos(String sol_apellidos) {
		this.sol_apellidos = sol_apellidos;
	}

	public String getSol_direccion() {
		return sol_direccion;
	}

	public void setSol_direccion(String sol_direccion) {
		this.sol_direccion = sol_direccion;
	}

	public String getSol_email() {
		return sol_email;
	}

	public void setSol_email(String sol_email) {
		this.sol_email = sol_email;
	}

	public String getSol_celular() {
		return sol_celular;
	}

	public void setSol_celular(String sol_celular) {
		this.sol_celular = sol_celular;
	}

	@Override
	public String toString() {
		return "Solicitante [sol_id=" + sol_id + ", sol_cedula=" + sol_cedula + ", sol_nombres=" + sol_nombres
				+ ", sol_apellidos=" + sol_apellidos + ", sol_direccion=" + sol_direccion + ", sol_email=" + sol_email
				+ ", sol_celular=" + sol_celular + "]";
	}

}
