package ups.edu.ec.dao;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import ups.edu.ec.modelo.Libro;
import ups.edu.ec.modelo.PrestamoLibro;
import ups.edu.ec.modelo.Solicitante;
import java.util.List;

@ApplicationScoped
public class RepositorioReserva {

	@Inject
	private EntityManager em;

	public boolean nuevoLibro(Libro newLibro) {
		try {
			em.persist(newLibro);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean nuevoSolicitante(Solicitante newSolicitante) {
		try {
			em.persist(newSolicitante);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean nuevoPrestamo(PrestamoLibro newPrestamo) {
		try {
			em.persist(newPrestamo);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean actualizaStock(String stk, String id) {
		try {
			Query q = em.createNativeQuery("update libro set lib_stk = " + stk + " where lib_id = " + id);
			q.executeUpdate();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean actualizaEstadoLibro(String id) {
		try {
			Query q = em.createNativeQuery(
					"update prestamolibro set pre_estado = 'INACTIVO'" + " where pre_id = " + id);
			q.executeUpdate();
			em.flush();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public String devuelveEmailSolicitante(String ced) {
		StoredProcedureQuery query = em.createStoredProcedureQuery("fn_devuelve_email")
				.registerStoredProcedureParameter("pv_cedula", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("pv_email", String.class, ParameterMode.OUT)
				.setParameter("pv_cedula", ced);

		query.execute();

		String retEmail = (String) query.getOutputParameterValue("pv_email");
		return retEmail;
	}

	public Solicitante buscarIdSolicitante(int id) {
		return em.find(Solicitante.class, id);
	}

	public Libro buscarIdLibro(int id) {
		return em.find(Libro.class, id);
	}

	public PrestamoLibro buscarIdPrestamoLibro(int id) {
		return em.find(PrestamoLibro.class, id);
	}

	public Solicitante buscarSolicitanteCedula(String cedula) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Solicitante> crite = cb.createQuery(Solicitante.class);
		Root<Solicitante> solicitante = crite.from(Solicitante.class);

		crite.select(solicitante).where(cb.equal(solicitante.get("sol_cedula"), cedula));
		return em.createQuery(crite).getSingleResult();
	}

	public Libro buscarLibroBarras(String cod_barras) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Libro> crite = cb.createQuery(Libro.class);
		Root<Libro> libro = crite.from(Libro.class);

		crite.select(libro).where(cb.equal(libro.get("lib_barras"), cod_barras));
		return em.createQuery(crite).getSingleResult();
	}

	public Solicitante buscarEmailSolicitante(String email) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Solicitante> crite = cb.createQuery(Solicitante.class);
		Root<Solicitante> solicitante = crite.from(Solicitante.class);

		crite.select(solicitante).where(cb.equal(solicitante.get("sol_email"), email));
		return em.createQuery(crite).getSingleResult();
	}

	public List<Libro> devuelveTodoOrdenandoNombreLibro() {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Libro> crite = cb.createQuery(Libro.class);
		Root<Libro> libro = crite.from(Libro.class);

		crite.select(libro).orderBy(cb.asc(libro.get("lib_nom")));
		return em.createQuery(crite).getResultList();
	}

	public List<Solicitante> devuelveTodoOrdenandoNombreSolicitante() {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Solicitante> crite = cb.createQuery(Solicitante.class);
		Root<Solicitante> solicitante = crite.from(Solicitante.class);

		crite.select(solicitante).orderBy(cb.asc(solicitante.get("sol_nombres")));
		return em.createQuery(crite).getResultList();
	}

	public List<PrestamoLibro> devuelveTodoOrdenandoFechaPrestamoLibro() {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<PrestamoLibro> crite = cb.createQuery(PrestamoLibro.class);
		Root<PrestamoLibro> prestamo = crite.from(PrestamoLibro.class);

		crite.select(prestamo).where(cb.and(cb.equal(prestamo.get("pre_estado"), "ACTIVO")))
				.orderBy(cb.asc(prestamo.get("pre_fecha_inicio")));
		return em.createQuery(crite).getResultList();
	}

	public List<PrestamoLibro> devuelveTodoOrdenandoFechaPrestamoLibroAI() {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<PrestamoLibro> crite = cb.createQuery(PrestamoLibro.class);
		Root<PrestamoLibro> prestamo = crite.from(PrestamoLibro.class);

		crite.select(prestamo).orderBy(cb.asc(prestamo.get("pre_fecha_inicio")));
		return em.createQuery(crite).getResultList();
	}
	
}
