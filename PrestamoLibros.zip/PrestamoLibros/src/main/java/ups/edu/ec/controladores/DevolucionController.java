package ups.edu.ec.controladores;

import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.enterprise.inject.Model;
import javax.enterprise.inject.Produces;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.inject.Inject;
import javax.inject.Named;

import ups.edu.ec.modelo.Libro;
import ups.edu.ec.modelo.PrestamoLibro;
import ups.edu.ec.modelo.Solicitante;
import ups.edu.ec.servicios.EnvioCorreo;
import ups.edu.ec.servicios.NegociosReserva;

@Model
public class DevolucionController {

	@Inject
	private FacesContext facesContext;

	@Inject
	private NegociosReserva negociosP;

	@Inject
	private Logger log;

	@PostConstruct
	public void initNewPrestamo() {

	}

	public void devuleve(String can, String stk, String id, String idLi) {
		try {
			if (negociosP.actualizaEstadoLibro(id) == true) {
				int stk1 = Integer.valueOf(can) + Integer.valueOf(stk);
				String stk2 = stk1 + "";
				if (negociosP.actualizaStock(stk2, idLi) == true) {
					FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_INFO, "Prestamo de libro Devuelto!",
							"Se registro la devolucion del prestamo satisfactoriamente.");
					facesContext.addMessage(null, m);
				} else {
					FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_INFO, "ERROR!",
							"NO SE PUDO REGISTRAR la devolucion del prestamo.");
					facesContext.addMessage(null, m);
				}
			} else {
				FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_INFO, "ERROR!",
						"NO SE PUDO REGISTRAR la devolucion del prestamo.");
				facesContext.addMessage(null, m);
			}

		} catch (Exception e) {
			FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_INFO, "ERROR!",
					"NO SE PUDO REGISTRAR la devolucion del prestamo.");
			facesContext.addMessage(null, m);
		}
	}

}
