package ups.edu.ec.modelo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import org.hibernate.validator.constraints.NotEmpty;

@SuppressWarnings("serial")
@Entity
@XmlRootElement
public class PrestamoLibro implements Serializable {

	@Id
	@GeneratedValue
	@Column(name = "pre_id")
	private int pre_id;

	@NotNull
	@JoinColumn(name = "pre_lib_id", referencedColumnName = "lib_id")
	@ManyToOne
	private Libro pre_lib;

	@NotNull
	@JoinColumn(name = "pre_sol_id", referencedColumnName = "sol_id")
	@ManyToOne
	private Solicitante pre_sol;

	@NotNull
	@NotEmpty
	@Column(name = "pre_fecha_inicio")
	private String pre_fecha_inicio;

	@NotNull
	@NotEmpty
	@Column(name = "pre_fecha_fin")
	private String pre_fecha_fin;

	@NotNull
	@NotEmpty
	@Column(name = "pre_estado")
	private String pre_estado;

	@NotNull
	@NotEmpty
	@Column(name = "pre_cantidad")
	private String pre_cantidad;

	public String getPre_cantidad() {
		return pre_cantidad;
	}

	public void setPre_cantidad(String pre_cantidad) {
		this.pre_cantidad = pre_cantidad;
	}

	public int getPre_id() {
		return pre_id;
	}

	public void setPre_id(int pre_id) {
		this.pre_id = pre_id;
	}

	public Libro getPre_lib() {
		return pre_lib;
	}

	public void setPre_lib(Libro pre_lib) {
		this.pre_lib = pre_lib;
	}

	public Solicitante getPre_sol() {
		return pre_sol;
	}

	public void setPre_sol(Solicitante pre_sol) {
		this.pre_sol = pre_sol;
	}

	public String getPre_fecha_inicio() {
		return pre_fecha_inicio;
	}

	public void setPre_fecha_inicio(String pre_fecha_inicio) {
		this.pre_fecha_inicio = pre_fecha_inicio;
	}

	public String getPre_fecha_fin() {
		return pre_fecha_fin;
	}

	public void setPre_fecha_fin(String pre_fecha_fin) {
		this.pre_fecha_fin = pre_fecha_fin;
	}

	public String getPre_estado() {
		return pre_estado;
	}

	public void setPre_estado(String pre_estado) {
		this.pre_estado = pre_estado;
	}

	@Override
	public String toString() {
		return "PrestamoLibro [pre_id=" + pre_id + ", pre_lib=" + pre_lib + ", pre_sol=" + pre_sol
				+ ", pre_fecha_inicio=" + pre_fecha_inicio + ", pre_fecha_fin=" + pre_fecha_fin + ", pre_estado="
				+ pre_estado + ", pre_cantidad=" + pre_cantidad + "]";
	}

}
