package ups.edu.ec.controladores;

import javax.annotation.PostConstruct;
import javax.enterprise.inject.Model;
import javax.enterprise.inject.Produces;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import ups.edu.ec.modelo.Solicitante;
import ups.edu.ec.servicios.NegociosReserva;

@Model
public class SolicitanteController {

	@Inject
	private FacesContext facesContext;

	@Inject
	private NegociosReserva negociosS;

	@Produces
	@Named
	private Solicitante newSolicitante;

	@PostConstruct
	public void initNewSolicitante() {
		newSolicitante = new Solicitante();
	}

	public void registrarSolicitante() throws Exception {
		try {
			if (negociosS.registroSolicitante(newSolicitante) == true) {
				FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_INFO, "Solicitante Registrado!",
						"Se registro el solicitante satisfactoriamente.");
				facesContext.addMessage(null, m);
				initNewSolicitante();
			} else {
				FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_INFO, "ERROR!",
						"No se pudo registrar el solicitante.");
				facesContext.addMessage(null, m);
			}

		} catch (Exception e) {
			String errorMensaje = getMensajeError(e);
			FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_ERROR, errorMensaje,
					"No se pudo registrar el solicitante.");
			facesContext.addMessage(null, m);
		}
	}

	private String getMensajeError(Exception e) {
		String errorMensaje = "Registro fallido de solicitante, tener en cuenta los Logs para más información.";
		if (e == null) {
			return errorMensaje;
		}

		Throwable t = e;
		while (t != null) {
			errorMensaje = t.getLocalizedMessage();
			t = t.getCause();
		}
		return errorMensaje;
	}

}
