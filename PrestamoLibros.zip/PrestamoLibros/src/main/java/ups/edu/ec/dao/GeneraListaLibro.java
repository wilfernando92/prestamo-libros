package ups.edu.ec.dao;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.Observes;
import javax.enterprise.event.Reception;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;
import ups.edu.ec.modelo.Libro;

import java.util.List;

@RequestScoped
public class GeneraListaLibro {

	@Inject
	private RepositorioReserva repositorioReserva;

	private List<Libro> libros;

	@Produces
	@Named
	public List<Libro> getLibros() {
		return libros;
	}

	public void listaLibrosCambios(@Observes(notifyObserver = Reception.IF_EXISTS) final Libro libro) {
		devuelveTodoOrden();
	}

	@PostConstruct
	public void devuelveTodoOrden() {
		libros = repositorioReserva.devuelveTodoOrdenandoNombreLibro();
	}
}
