package ups.edu.ec.controladores;

import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.enterprise.inject.Model;
import javax.enterprise.inject.Produces;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.inject.Inject;
import javax.inject.Named;

import ups.edu.ec.modelo.Libro;
import ups.edu.ec.modelo.PrestamoLibro;
import ups.edu.ec.modelo.Solicitante;
import ups.edu.ec.servicios.EnvioCorreo;
import ups.edu.ec.servicios.NegociosReserva;

@ManagedBean
@ApplicationScoped
public class PrestamoController {

	@Inject
	private FacesContext facesContext;

	@Inject
	private NegociosReserva negociosP;

	@Produces
	@Named
	private PrestamoLibro newPrestamo;

	@Produces
	@Named
	private String cedula;

	@Produces
	@Named
	private String nombres;

	@Produces
	@Named
	private String libro;

	@Produces
	@Named
	private String stk;

	@Produces
	@Named
	private String cod_barras;

	@Produces
	@Named
	private String fecha_inicio;

	@Produces
	@Named
	private String fecha_fin;

	@Produces
	@Named
	private String canti;

	@Inject
	private Logger log;

	private PrestamoLibro pres;

	public String getStk() {
		return stk;
	}

	public void setStk(String stk) {
		this.stk = stk;
	}

	public String getCanti() {
		return canti;
	}

	public void setCanti(String canti) {
		this.canti = canti;
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getLibro() {
		return libro;
	}

	public void setLibro(String libro) {
		this.libro = libro;
	}

	public String getCedula() {
		return cedula;
	}

	public void setCedula(String cedula) {
		this.cedula = cedula;
	}

	public String getCod_barras() {
		return cod_barras;
	}

	public void setCod_barras(String cod_barras) {
		this.cod_barras = cod_barras;
	}

	public String getFecha_inicio() {
		return fecha_inicio;
	}

	public void setFecha_inicio(String fecha_inicio) {
		this.fecha_inicio = fecha_inicio;
	}

	public String getFecha_fin() {
		return fecha_fin;
	}

	public void setFecha_fin(String fecha_fin) {
		this.fecha_fin = fecha_fin;
	}

	@PostConstruct
	public void initNewPrestamo() {
		newPrestamo = new PrestamoLibro();
		pres = new PrestamoLibro();
		cedula = "";
		cod_barras = "";
		fecha_inicio = "";
		fecha_fin = "";
		nombres = "";
		libro = "";
		stk = "";
		canti = "";
	}

	public void getSoli() {
		log.info("Buscado al solicitante controller " + cedula);
		try {
			Solicitante newUsuario2 = negociosP.buscaSolicitanteCedula(cedula);
			log.info("Buscado al solicitante controller APELLIDOS " + newUsuario2.getSol_apellidos());
			pres.setPre_sol(newUsuario2);

			nombres = pres.getPre_sol().getSol_nombres() + " " + pres.getPre_sol().getSol_apellidos();

		} catch (Exception e) {
			nombres = "CLIENTE NO ENCONTRADO";
		}

	}

	public void getLibr() {
		log.info("Buscado al libro controller " + cod_barras);
		try {
			Libro newLibro2 = negociosP.buscaLibroBarras(cod_barras);
			log.info("Buscado al libro controller LIBRO " + newLibro2.getLib_nom());
			pres.setPre_lib(newLibro2);

			libro = pres.getPre_lib().getLib_nom();
			stk = pres.getPre_lib().getLib_stk();

		} catch (Exception e) {
			libro = "LIBRO NO ENCONTRADO";
			stk = "0";
		}
	}

	public void validaTodo() throws Exception {
		log.info("LLEGA A LA VALIDACION");
		pres.setPre_fecha_inicio(fecha_inicio);
		pres.setPre_fecha_fin(fecha_fin);
		pres.setPre_estado("ACTIVO");
		pres.setPre_cantidad(canti);
		newPrestamo = pres;
		log.info(newPrestamo.toString());
		if (Integer.valueOf(newPrestamo.getPre_cantidad().toString()) <= Integer
				.valueOf(newPrestamo.getPre_lib().getLib_stk().toString())) {
			if (newPrestamo.getPre_sol() != null && newPrestamo.getPre_lib() != null
					&& !newPrestamo.getPre_fecha_fin().equals("") && !newPrestamo.getPre_fecha_inicio().equals("")) {
				registrarPrestamo();
			} else {
				FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_INFO,
						"NO se puede registrar el prestamo, campos vacios", "ERROR!!");
				facesContext.addMessage(null, m);
			}
		} else {
			FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_INFO, "No hay suficiente STOCK!", "ERROR!!");
			facesContext.addMessage(null, m);
		}

	}

	public void registrarPrestamo() throws Exception {
		try {
			if (negociosP.registroPrestamo(newPrestamo) == true) {
				int stk1 = Integer.valueOf(newPrestamo.getPre_lib().getLib_stk().toString())
						- Integer.valueOf(newPrestamo.getPre_cantidad().toString());
				String stk2 = stk1 + "";
				String id1 = newPrestamo.getPre_lib().getLib_id() + "";
				negociosP.actualizaStock(stk2, id1);
				FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_INFO, "Prestamo Registrado!",
						"Se registro el prestamo satisfactoriamente.");
				facesContext.addMessage(null, m);

				// envia correo
				try {
					EnvioCorreo e = new EnvioCorreo();
					if (e.envio(newPrestamo.getPre_sol().getSol_email(),
							newPrestamo.getPre_sol().getSol_nombres() + ", bienvenid@ a Aplicaciones Distribuidas",
							"Su prestamo del libro " + newPrestamo.getPre_lib().getLib_nom()
									+ " se realizo correctamente, " + ", recuerde que tiene hasta el "
									+ newPrestamo.getPre_fecha_fin()
									+ " para devolver el libro. Saludos Cordiales.") == true) {
						m = new FacesMessage(FacesMessage.SEVERITY_INFO,
								"Correo de confirmacion de prestamo enviado a "
										+ newPrestamo.getPre_sol().getSol_email(),
								"Se envio el correo de confirmacion de prestamo satisfactoriamente.");
						facesContext.addMessage(null, m);
					} else {
						m = new FacesMessage(FacesMessage.SEVERITY_INFO, "Error al enviar correo de prestamo.",
								"No se pudo enviar el correo de confirmacion de prestamo.");
						facesContext.addMessage(null, m);
					}

				} catch (Exception e) {
					m = new FacesMessage(FacesMessage.SEVERITY_INFO, "Error al enviar correo de prestamo.",
							"No se pudo enviar el correo de confirmacion de prestamo.");
					facesContext.addMessage(null, m);
				}

				initNewPrestamo();
			} else {
				FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_INFO, "ERROR!",
						"No se pudo registrar el prestamo.");
				facesContext.addMessage(null, m);
			}
		} catch (Exception e) {
			String errorMensaje = getMensajeError(e);
			FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_ERROR, errorMensaje,
					"No se pudo registrar el prestamo.");
			facesContext.addMessage(null, m);
		}
	}

	private String getMensajeError(Exception e) {
		String errorMensaje = "Registro fallido de prestamo, tener en cuenta los Logs para más información.";
		if (e == null) {
			return errorMensaje;
		}

		Throwable t = e;
		while (t != null) {
			errorMensaje = t.getLocalizedMessage();
			t = t.getCause();
		}
		return errorMensaje;
	}

}
