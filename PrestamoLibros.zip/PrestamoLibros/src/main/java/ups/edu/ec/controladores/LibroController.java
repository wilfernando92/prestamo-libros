package ups.edu.ec.controladores;

import javax.annotation.PostConstruct;
import javax.enterprise.inject.Model;
import javax.enterprise.inject.Produces;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import ups.edu.ec.modelo.Libro;
import ups.edu.ec.servicios.NegociosReserva;

@Model
public class LibroController {

	@Inject
	private FacesContext facesContext;

	@Inject
	private NegociosReserva negociosL;

	@Produces
	@Named
	private Libro newLibro;

	@PostConstruct
	public void initNewLibro() {
		newLibro = new Libro();
	}

	public void registrarLibro() throws Exception {
		try {
			if (negociosL.registroLibro(newLibro) == true) {
				FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_INFO, "Libro Registrado!",
						"Se registro el libro satisfactoriamente.");
				facesContext.addMessage(null, m);
				initNewLibro();
			} else {
				FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_INFO, "ERROR!",
						"No se pudo registrar el libro.");
				facesContext.addMessage(null, m);
			}

		} catch (Exception e) {
			String errorMensaje = getMensajeError(e);
			FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_ERROR, errorMensaje,
					"No se pudo registrar el libro.");
			facesContext.addMessage(null, m);
		}
	}

	private String getMensajeError(Exception e) {
		String errorMensaje = "Registro fallido de libro, tener en cuenta los Logs para más información.";
		if (e == null) {
			return errorMensaje;
		}

		Throwable t = e;
		while (t != null) {
			errorMensaje = t.getLocalizedMessage();
			t = t.getCause();
		}
		return errorMensaje;
	}

}
