package ups.edu.ec.controladores;

import javax.annotation.PostConstruct;
import javax.enterprise.inject.Model;
import javax.enterprise.inject.Produces;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import ups.edu.ec.modelo.Solicitante;
import ups.edu.ec.servicios.NegociosReserva;

@Model
public class InicioController {

	@Inject
	private FacesContext facesContext;

	@PostConstruct
	public void initNewInicio() {
		
	}

	public String inicio() {
		return "index";
	}
	
	public String prestamo() {
		return "prestamo";
	}
	
	public String solicitante() {
		return "solicitante";
	}
	
	public String libros() {
		return "libros";
	}
	
	public String devolucion() {
		return "devolucion";
	}
	
	public String reporte() {
		return "reporte";
	}
}
