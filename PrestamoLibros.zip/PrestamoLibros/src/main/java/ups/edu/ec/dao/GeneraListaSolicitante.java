package ups.edu.ec.dao;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.Observes;
import javax.enterprise.event.Reception;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;
import ups.edu.ec.modelo.Solicitante;

import java.util.List;

@RequestScoped
public class GeneraListaSolicitante {

	@Inject
	private RepositorioReserva repositorioReserva;

	private List<Solicitante> solicitantes;

	@Produces
	@Named
	public List<Solicitante> getSolicitantes() {
		return solicitantes;
	}

	public void listaSolicitantesCambios(@Observes(notifyObserver = Reception.IF_EXISTS) final Solicitante solicitante) {
		devuelveTodoOrden();
	}

	@PostConstruct
	public void devuelveTodoOrden() {
		solicitantes = repositorioReserva.devuelveTodoOrdenandoNombreSolicitante();
	}
}
