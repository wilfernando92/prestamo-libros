package ups.edu.ec.servicios;

import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;

import ups.edu.ec.dao.RepositorioReserva;
import ups.edu.ec.modelo.Libro;
import ups.edu.ec.modelo.PrestamoLibro;
import ups.edu.ec.modelo.Solicitante;

import java.util.List;
import java.util.logging.Logger;

@Stateless
public class NegociosReserva {

	@Inject
	private RepositorioReserva repositorioReserva;

	@Inject
	private Logger log;

	@Inject
	private Event<Libro> libroEventoSrc;

	@Inject
	private Event<PrestamoLibro> prestamoEventoSrc;

	@Inject
	private Event<Solicitante> solicitanteEventoSrc;

	public Solicitante buscaSolicitanteCedula(String cedula) {
		log.info("BUscando al solicitante Neogicios, " + cedula);
		try {
			return repositorioReserva.buscarSolicitanteCedula(cedula);
		} catch (Exception e) {
			log.info("Error al obtener solicitante.");
			return null;
		}
	}

	public Libro buscaLibroBarras(String cod_barras) {
		log.info("BUscando al libro Neogicios, " + cod_barras);
		try {
			return repositorioReserva.buscarLibroBarras(cod_barras);
		} catch (Exception e) {
			log.info("Error al obtener el libro.");
			return null;
		}
	}

	public boolean registroLibro(Libro newLibro) {
		log.info("Registrando al libro " + newLibro.getLib_nom());

		if (repositorioReserva.nuevoLibro(newLibro) == true) {
			log.info(newLibro.getLib_nom() + ", se registro correctamente.");
			libroEventoSrc.fire(newLibro);
			return true;
		} else {
			log.info(newLibro.getLib_nom() + ", NO SE PUDO REGISTRAR");
			return false;
		}
	}

	public boolean registroSolicitante(Solicitante newSolicitante) {
		log.info("Registrando al solicitante " + newSolicitante.getSol_nombres() + " "
				+ newSolicitante.getSol_apellidos());

		if (repositorioReserva.nuevoSolicitante(newSolicitante) == true) {
			log.info(newSolicitante.getSol_nombres() + ", se registro correctamente.");
			solicitanteEventoSrc.fire(newSolicitante);
			return true;
		} else {
			log.info(newSolicitante.getSol_nombres() + ", NO SE PUDO REGISTRAR");
			return false;
		}
	}

	public boolean actualizaStock(String stk, String id) {
		log.info("Actualizando Stock ");
		if (repositorioReserva.actualizaStock(stk, id) == true) {
			log.info("Stock actualizado a " + stk + " del libro " + id);
			return true;
		} else {
			log.info("NO SE PUDO ACTUALIZA Stock de " + stk + " del libro " + id);
			return false;
		}
	}
	
	public boolean actualizaEstadoLibro(String id) {
		log.info("Actualizando Estado ");
		if (repositorioReserva.actualizaEstadoLibro(id) == true) {
			log.info("Estado actualizado a " + "INACTIVO" + " del prestamo " + id);
			return true;
		} else {
			log.info("NO SE PUDO ACTUALIZAR ESTADO DE PRESTAMO " + " del prestamo " + id);
			return false;
		}
	}

	public boolean registroPrestamo(PrestamoLibro newPrestamo) {
		log.info("Registrando nuevo prestamo de " + newPrestamo.getPre_sol().getSol_nombres() + " del libro "
				+ newPrestamo.getPre_lib().getLib_nom());

		if (repositorioReserva.nuevoPrestamo(newPrestamo) == true) {
			log.info("Prestamo de " + newPrestamo.getPre_lib().getLib_nom() + ", se registro correctamente.");
			prestamoEventoSrc.fire(newPrestamo);
			return true;
		} else {
			log.info("Prestamo de " + newPrestamo.getPre_lib().getLib_nom() + ", NO SE PUDO REGISTRAR");
			return false;
		}
	}

	public List<Libro> listadoLibro() {
		return repositorioReserva.devuelveTodoOrdenandoNombreLibro();
	}

	public List<Solicitante> listadoSolicitante() {
		return repositorioReserva.devuelveTodoOrdenandoNombreSolicitante();
	}

	public List<PrestamoLibro> listadoPrestamoLibro() {
		return repositorioReserva.devuelveTodoOrdenandoFechaPrestamoLibro();
	}
	
	public List<PrestamoLibro> listadoPrestamoLibroAI() {
		return repositorioReserva.devuelveTodoOrdenandoFechaPrestamoLibroAI();
	}

}
