package ups.edu.ec.modelo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import org.hibernate.validator.constraints.NotEmpty;

@SuppressWarnings("serial")
@Entity
@XmlRootElement
@Table(uniqueConstraints = @UniqueConstraint(columnNames = "lib_barras"))
public class Libro implements Serializable {

	@Id
	@GeneratedValue
	@Column(name = "lib_id")
	private int lib_id;

	@NotNull
	@NotEmpty
	@Column(name = "lib_barras")
	private String lib_barras;

	@NotNull
	@NotEmpty
	@Column(name = "lib_nom")
	private String lib_nom;

	@NotNull
	@NotEmpty
	@Column(name = "lib_editorial")
	private String lib_editorial;

	@NotNull
	@NotEmpty
	@Column(name = "lib_autor")
	private String lib_autor;

	@NotNull
	@NotEmpty
	@Column(name = "lib_stk")
	private String lib_stk;

	public String getLib_stk() {
		return lib_stk;
	}

	public void setLib_stk(String lib_stk) {
		this.lib_stk = lib_stk;
	}

	public int getLib_id() {
		return lib_id;
	}

	public void setLib_id(int lib_id) {
		this.lib_id = lib_id;
	}

	public String getLib_barras() {
		return lib_barras;
	}

	public void setLib_barras(String lib_barras) {
		this.lib_barras = lib_barras;
	}

	public String getLib_nom() {
		return lib_nom;
	}

	public void setLib_nom(String lib_nom) {
		this.lib_nom = lib_nom;
	}

	public String getLib_editorial() {
		return lib_editorial;
	}

	public void setLib_editorial(String lib_editorial) {
		this.lib_editorial = lib_editorial;
	}

	public String getLib_autor() {
		return lib_autor;
	}

	public void setLib_autor(String lib_autor) {
		this.lib_autor = lib_autor;
	}

	@Override
	public String toString() {
		return "Libro [lib_id=" + lib_id + ", lib_barras=" + lib_barras + ", lib_nom=" + lib_nom + ", lib_editorial="
				+ lib_editorial + ", lib_autor=" + lib_autor + ", lib_stk=" + lib_stk + "]";
	}

}
