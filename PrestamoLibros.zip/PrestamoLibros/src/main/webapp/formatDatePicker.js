$(document).ready(function() {
	$( ".datepicker" ).datepicker({
		dateFormat: 'dd MM, yy',
		changeMonth: true,
		changeYear: true,
		yearRange: "1960:2017"
	});
});