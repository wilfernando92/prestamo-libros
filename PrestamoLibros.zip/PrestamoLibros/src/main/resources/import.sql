insert into Cliente (id, cedula, nombres, apellidos, celular, email) values (0, '0301756904', 'Fernando', 'Palomeque', '0987618241', 'wilfernando92@gmail.com') 
