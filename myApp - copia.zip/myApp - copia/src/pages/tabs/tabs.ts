import { Component } from '@angular/core';

import { ReservaPage } from '../reserva/reserva';
import { ListaLibrosPage } from '../lista-libros/lista-libros';
import { HomePage } from '../home/home';
import { NuevoLibroPage } from '../nuevo-libro/nuevo-libro'
import { PrestamosPage } from '../prestamos/prestamos'
import { DevolucionPage } from '../devolucion/devolucion';

@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {

  tab1Root = HomePage;
  tab2Root = ListaLibrosPage;
  tab3Root = ReservaPage;
  tab4Root = NuevoLibroPage;
  tab5Root = PrestamosPage;
  tab6Root = DevolucionPage;

  constructor() {

  }
}
