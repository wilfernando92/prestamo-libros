import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { UserServiceProvider } from '../../providers/user-service/user-service';

/**
 * Generated class for the ListaLibrosPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-lista-libros',
  templateUrl: 'lista-libros.html',
})
export class ListaLibrosPage {

  libros: any[] = [];

  constructor(public navCtrl: NavController, public navParams: NavParams, public UserServiceProvider: UserServiceProvider) {
  }

    ionViewDidLoad(){
    this.UserServiceProvider.getLibros()
    .subscribe(
      (data) => { // Success
        this.libros = data['libro'];
      },
      (error) =>{
        console.error(error);
      }
    )
  }

}
