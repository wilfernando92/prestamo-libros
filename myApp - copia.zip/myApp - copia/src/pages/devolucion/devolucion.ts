import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserServiceProvider } from '../../providers/user-service/user-service';
import { ReservavaServiceProvider } from '../../providers/reservava-service/reservava-service';

/**
 * Generated class for the DevolucionPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-devolucion',
  templateUrl: 'devolucion.html',
})
export class DevolucionPage {

  presta: any[] = [];

  myForm: FormGroup;

  constructor(public navCtrl: NavController, public navParams: NavParams, public formBuilder: FormBuilder, public UserServiceProvider3: UserServiceProvider, public resP3: ReservavaServiceProvider, public toastCtrl: ToastController) {
    this.myForm = this.createMyForm();
  }

  saveData(){
    this.UserServiceProvider3.getDevo(this.myForm.value.pre_id)
    .subscribe(
      (data) => { // Success
        let toast = this.toastCtrl.create({
          message: 'Devolucion realizada correctamente',
          position: 'bottom',
          duration: 3000
          });
          toast.present();
      },
      (error) =>{
        let toast = this.toastCtrl.create({
          message: 'Error al ingresar la devolucion',
          position: 'bottom',
          duration: 3000
          });
          toast.present();
      
          console.log(error);
      }
    )
    this.navCtrl.setRoot(this.navCtrl.getActive().component);
 }

 private createMyForm(){
  return this.formBuilder.group({
    pre_id: ['', Validators.required],
  });
}

  ionViewDidLoad(){//this.devices.map(function(a) {return a["_id"];})
  console.log(this.resP3.GlobalVarS['sol_id']);
    this.resP3.getPrestamosUsuario(this.resP3.GlobalVarS['sol_id'])
    .subscribe(
      (data) => { // Success
        this.presta = data['pre'];
      },
      (error) =>{
        console.error(error);
      }
    )
  }


}
