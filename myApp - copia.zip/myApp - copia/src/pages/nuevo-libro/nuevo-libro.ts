import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserServiceProvider } from '../../providers/user-service/user-service';

/**
 * Generated class for the NuevoLibroPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-nuevo-libro',
  templateUrl: 'nuevo-libro.html',
})
export class NuevoLibroPage {
	
  myForm: FormGroup;

  constructor(public navCtrl: NavController, public navParams: NavParams, public formBuilder: FormBuilder, public UserServiceProvider: UserServiceProvider, public toastCtrl: ToastController) {
  this.myForm = this.createMyForm();
  }

libro = { lib_barras: '', lib_nom: '', lib_editorial: '', lib_autor: '', lib_stk: '' };


saveData(){
     this.UserServiceProvider.addLibro(this.myForm.value).then((result) => {
    console.log(result);

let toast = this.toastCtrl.create({
message: 'Libro ingresado correctamente',
position: 'bottom',
duration: 3000
});
toast.present();

  }, (err) => {

let toast = this.toastCtrl.create({
message: 'Error al ingresar el libro',
position: 'bottom',
duration: 3000
});
toast.present();

    console.log(err);
  });
    console.log(this.myForm.value);
this.navCtrl.setRoot(this.navCtrl.getActive().component);
  }

  private createMyForm(){
    return this.formBuilder.group({
      lib_barras: ['', Validators.required],
      lib_nom: ['', Validators.required],
      lib_editorial: ['', Validators.required],
      lib_autor: ['', Validators.required],
      lib_stk: ['', Validators.required],
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NuevoLibroPage');
  }

}
