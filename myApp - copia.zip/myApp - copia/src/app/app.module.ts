import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { IonicApp, IonicModule, IonicErrorHandler, LoadingController, Loading, AlertController } from 'ionic-angular';
import { ToastController } from 'ionic-angular';
import { MyApp } from './app.component';

import { ReservaPage } from '../pages/reserva/reserva';
import { ListaLibrosPage } from '../pages/lista-libros/lista-libros';
import { HomePage } from '../pages/home/home';
import { TabsPage } from '../pages/tabs/tabs';
import { NuevoLibroPage } from '../pages/nuevo-libro/nuevo-libro';
import { PrestamosPage } from '../pages/prestamos/prestamos';
import { DevolucionPage } from '../pages/devolucion/devolucion';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { UserServiceProvider } from '../providers/user-service/user-service';
import { ReservavaServiceProvider } from '../providers/reservava-service/reservava-service';
import { LoginPage } from '../pages/login/login';

@NgModule({
  declarations: [
    MyApp,
    ReservaPage,
    ListaLibrosPage,
    HomePage,
    NuevoLibroPage,
    LoginPage,
    PrestamosPage,
    DevolucionPage,
    TabsPage
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    ReservaPage,
    ListaLibrosPage,
    HomePage,
    NuevoLibroPage,
    LoginPage,
    PrestamosPage,
    DevolucionPage,
    TabsPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    UserServiceProvider,
    ReservavaServiceProvider
  ]
})
export class AppModule {}
